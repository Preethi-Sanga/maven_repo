package com.maven.maven_project;

public interface Gift {
	public String getName();
	public int getWeight();
	public void setName(String a);
	public void setWeight(int i);
}
